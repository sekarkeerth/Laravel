<?php echo Form::open(['route' => 'order.store', 'class' => 'form']); ?>

 
<?php echo e(csrf_field()); ?>

<h1> Order </h1>
<div class="form-group">
    <?php echo Form::label('name', 'Name'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('currency', 'Currency'); ?>

    <?php echo Form::text('currency', null, ['class' => 'form-control']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('price', 'Price'); ?>

    <?php echo Form::text('price', null, ['class' => 'form-control']); ?>

</div>
<br>
<h1> Payment </h1>
<div class="form-group">
    <?php echo Form::label('type', 'Type'); ?>

    <?php echo Form::text('type', null, ['class' => 'form-control']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('card_holder_name', 'Credit card Holder name'); ?>

    <?php echo Form::text('card_holder_name', null, ['class' => 'form-control']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('credit_card_number', 'Credit Card No'); ?>

    <?php echo Form::text('credit_card_number', null, ['class' => 'form-control']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('credit_card_number_cvv', 'Credit Card Cvv'); ?>

    <?php echo Form::text('credit_card_number_cvv', null, ['class' => 'form-control']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('credit_card_number_expire', 'Credit Card Expiry'); ?>

    <?php echo Form::text('credit_card_number_expire', null, ['class' => 'form-control']); ?>

</div>

<!--
<div class="form-group">
    <?php echo Form::textarea('msg', null, ['class' => 'form-control']); ?>

</div>
-->
<?php if(session()->has('alert-success')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('alert-success')); ?>

    </div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<br>

<?php echo Form::submit('Submit', ['class' => 'btn btn-info']); ?>


<?php echo Form::close(); ?>