{!! Form::open(['route' => 'order.store', 'class' => 'form']) !!}
 
{{ csrf_field() }}
<h1> Order </h1>
<div class="form-group">
    {!! Form::label('name', 'Name') !!}
    {!! Form::text('name', null, ['class' => 'form-control']) !!}
</div>

<div class="form-group">
    {!! Form::label('currency', 'Currency') !!}
    {!! Form::text('currency', null, ['class' => 'form-control']) !!}
</div>

<div class="form-group">
    {!! Form::label('price', 'Price') !!}
    {!! Form::text('price', null, ['class' => 'form-control']) !!}
</div>
<br>
<h1> Payment </h1>
<div class="form-group">
    {!! Form::label('type', 'Type') !!}
    {!! Form::text('type', null, ['class' => 'form-control']) !!}
</div>

<div class="form-group">
    {!! Form::label('card_holder_name', 'Credit card Holder name') !!}
    {!! Form::text('card_holder_name', null, ['class' => 'form-control']) !!}
</div>

<div class="form-group">
    {!! Form::label('credit_card_number', 'Credit Card No') !!}
    {!! Form::text('credit_card_number', null, ['class' => 'form-control']) !!}
</div>

<div class="form-group">
    {!! Form::label('credit_card_number_cvv', 'Credit Card Cvv') !!}
    {!! Form::text('credit_card_number_cvv', null, ['class' => 'form-control']) !!}
</div>

<div class="form-group">
    {!! Form::label('credit_card_number_expire', 'Credit Card Expiry') !!}
    {!! Form::text('credit_card_number_expire', null, ['class' => 'form-control']) !!}
</div>

<!--
<div class="form-group">
    {!! Form::textarea('msg', null, ['class' => 'form-control']) !!}
</div>
-->
@if(session()->has('alert-success'))
    <div class="alert alert-success">
        {{ session()->get('alert-success') }}
    </div>
@endif

@if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

<br>

{!! Form::submit('Submit', ['class' => 'btn btn-info']) !!}

{!! Form::close() !!}