<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Requests\OrderFormRequest;
use DB;
use App\Order;
use App\Payment;


class OrderController extends Controller {

    public function create()
    {
        return view('Order.create');
    }

    public function store(OrderFormRequest $request)
    {
        //Payment record insert
        $payment = new Payment;
        $payment->transaction_id = '123456';
        $payment->status = 'approved';
        $payment->client_id = '12345';
        $payment->payment_status = 'paid';
        $payment->type = $request->type;
        $payment->save();
    
        //Order record insert
         $order = new Order;
        $order->name = $request->name;
        $order->currency = $request->currency;
        $order->price = $request->price;
        $order->payment_id = $payment->id;
        $order->save();
     
        
    // Mail delivery logic goes here

    //flash('Your message has been sent!')->success();

    return redirect()->route('order.create')->with('alert-success', 'You have done successfully');;

    }

}